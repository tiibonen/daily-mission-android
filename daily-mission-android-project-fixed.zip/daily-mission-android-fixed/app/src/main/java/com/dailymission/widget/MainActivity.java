package com.dailymission.widget;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tv = new TextView(this);
        tv.setText("Daily Mission\n\nAdd the Daily Mission widget from your Home screen → Widgets.");
        tv.setTextSize(20);
        tv.setTextColor(Color.WHITE);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(40,40,40,40);
        tv.setBackgroundColor(Color.rgb(18, 18, 18));
        setContentView(tv);
    }
}
